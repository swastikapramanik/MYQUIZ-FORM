class Contestant {
  constructor(){
    this.index = null;
    this.answer = 0;
    this.name = null;
  }}
